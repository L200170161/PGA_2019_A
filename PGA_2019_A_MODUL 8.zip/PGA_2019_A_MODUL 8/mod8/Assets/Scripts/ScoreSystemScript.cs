﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreSystemScript : MonoBehaviour {
	public Transform player;
	public Transform Diamond;
	public float dist;
	public int score;

	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag("Player").transform;
	}
	
	// Update is called once per frame
	void Update () {
		Diamond = GameObject.FindGameObjectWithTag("Diamond").transform;
		dist = Vector3.Distance(player.position, Diamond.position);
		if (dist <= 1){
			score += 1;
		}
	}
}
